#!/bin/bash

set -euo pipefail

environment_root="$1"
conda_executable="$2"
package_root="$(cd "$(dirname "$0")" && pwd)"
log_file="$package_root/homebrew-install.log"
tuna_channel="https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/conda-forge"
official_channel="https://conda.anaconda.org/conda-forge"
tuna_pypi="https://pypi.tuna.tsinghua.edu.cn/simple"

case "$environment_root" in
    */Cellar/ddrimage/*/libexec/environment) ;;
    *)
        echo "Refusing to prepare an unexpected environment path: $environment_root" >&2
        exit 2
        ;;
esac

install_conda_environment() {
    local channel="$1"
    "$conda_executable" create -y -p "$environment_root" \
        --override-channels -c "$channel" \
        --file "$package_root/requirements-macos-conda.txt"
}

rm -rf "$environment_root"
if ! install_conda_environment "$tuna_channel" >>"$log_file" 2>&1; then
    echo "The mirror failed; retrying with the official conda-forge channel." >>"$log_file"
    rm -rf "$environment_root"
    install_conda_environment "$official_channel" >>"$log_file" 2>&1
fi

python_executable="$environment_root/bin/python"
macos_major="$(sw_vers -productVersion | cut -d. -f1)"
if [ "$macos_major" -ge 13 ]; then
    pyside_requirement="PySide6==6.11.2"
elif [ "$macos_major" -eq 12 ]; then
    pyside_requirement="PySide6==6.8.3"
else
    pyside_requirement="PySide6==6.6.3.1"
fi

if ! "$python_executable" -m pip install --disable-pip-version-check \
        --prefer-binary --index-url "$tuna_pypi" \
        -r "$package_root/requirements-macos-pip.txt" "$pyside_requirement" \
        >>"$log_file" 2>&1; then
    echo "The PyPI mirror failed; retrying with the official index." >>"$log_file"
    "$python_executable" -m pip install --disable-pip-version-check \
        --prefer-binary -r "$package_root/requirements-macos-pip.txt" \
        "$pyside_requirement" \
        >>"$log_file" 2>&1
fi

"$python_executable" -c "import sys; assert sys.version_info[:2] == (3, 12); import PySide6,numpy,scipy,pandas,matplotlib,PIL,tifffile,skimage,cv2,liffile; print('DDRimage runtime OK')" \
    >>"$log_file" 2>&1
