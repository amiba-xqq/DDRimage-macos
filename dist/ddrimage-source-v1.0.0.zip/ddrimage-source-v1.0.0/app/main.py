from __future__ import annotations

import json
import math
import os
import re
import sys
import ctypes
from pathlib import Path

from matplotlib import colormaps as MPL_COLORMAPS
from PySide6.QtCore import QProcess, QProcessEnvironment, QSize, Qt, QUrl
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon, QImage, QPainter, QPixmap, QTextCursor
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QColorDialog, QComboBox, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QMainWindow, QMessageBox,
    QPushButton, QScrollArea, QSizePolicy, QSplitter, QStackedWidget,
    QTextEdit, QVBoxLayout, QWidget,
)


APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
ICON_FILE = ROOT_DIR / "assets" / ("ddrimage.ico" if sys.platform == "win32" else "ddrimage-icon.png")
DATA_DIR = Path(os.environ.get("DDRIMAGE_DATA_DIR", str(ROOT_DIR / "data"))).expanduser()
STATE_FILE = DATA_DIR / "settings.json"
RUN_FILE = DATA_DIR / "last_run.json"
PREVIEW_DIR = DATA_DIR / "previews"
PREVIEW_PREFIX = "DDRIMAGE_PREVIEW:"
NATURE_COLORS = ["#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F",
                 "#8491B4", "#91D1C2", "#DC0000", "#7E6148", "#B09C85"]
PRISM_COLORS = ["#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD",
                "#8C564B", "#E377C2", "#7F7F7F", "#BCBD22", "#17BECF",
                "#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F", "#91D1C2"]
HEX_COLOR = re.compile(r"#[0-9A-Fa-f]{6}")
_COLORBAR_ICONS = None


def field(key, label, default, kind="text", help_text="", targets=(), choices=(), group="参数"):
    return dict(key=key, label=label, default=default, kind=kind, help=help_text,
                targets=list(targets), choices=list(choices), group=group)


class NoWheelComboBox(QComboBox):
    """A combo box that only changes selection by click/keyboard, never wheel."""

    def wheelEvent(self, event):
        event.ignore()  # Let the enclosing page/log scroll area consume the wheel.


def _colorbar_icon(colors):
    pixmap = QPixmap(170, 18)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    try:
        width = pixmap.width()
        for index, color in enumerate(colors):
            left = round(index * width / len(colors))
            right = round((index + 1) * width / len(colors))
            painter.fillRect(left, 0, max(1, right - left), pixmap.height(), QColor(color))
    finally:
        painter.end()
    return QIcon(pixmap)


def colorbar_icons():
    global _COLORBAR_ICONS
    if _COLORBAR_ICONS is None:
        icons = {"nature": _colorbar_icon(NATURE_COLORS)}
        for name in sorted(MPL_COLORMAPS):
            cmap = MPL_COLORMAPS[name]
            samples = []
            for index in range(32):
                red, green, blue, _ = cmap(index / 31)
                samples.append(QColor.fromRgbF(float(red), float(green), float(blue)).name())
            icons[name] = _colorbar_icon(samples)
        _COLORBAR_ICONS = icons
    return _COLORBAR_ICONS


PAGES = [
    dict(
        id="lif", title="LIF 导出 TIFF", icon="01", warning=False,
        description="将 Leica LIF 批量导出为合并图和独立通道 TIFF。输出到所选文件夹旁的“_tif”文件夹。",
        fields=[
            field("input_dir", "LIF 文件夹", "", "folder", "选择存放 .lif 文件的文件夹。",
                  [("lif2tif.py", "input_dir")], group="输入"),
        ], stages=[("lif2tif.py", "导出 LIF")],
    ),
    dict(
        id="foci", title="细胞核内 Foci", icon="02", warning=True,
        description="读取 LIF 导出的 TIFF，统计每个细胞核内的蛋白 foci，并生成分组散点图与统计结果。",
        fields=[
            field("input_dir", "TIFF 母文件夹", "", "folder", "选择 lif2tif 生成的 *_tif 文件夹；其中应包含各 LIF 对应的子文件夹。", [("nucleus_foci.py", "input_dir"), ("foci_plot.py", "input_dir")], group="输入"),
            field("run_step", "本次运行步骤", "analysis", "choice", "二选一：图像统计生成 CSV/标注图；统计作图只读取已有 CSV，不重新分析图片。", choices=[("analysis", "仅运行图像统计"), ("plot", "仅生成统计图")], group="步骤"),
            field("foci_mode", "处理范围", "test", "choice", "可选范围：test 或 all；test 只处理首个子文件夹的首张合并图，all 处理全部。", [("nucleus_foci.py", "foci_mode")], [("test", "测试一张"), ("all", "全部处理")], "统计参数"),
            field("nucleus_area_px", "细胞核面积 (px²)", [1000, 20000], "pair_int", "整数范围：1 ≤ 下限 ≤ 上限；仅保留面积处于闭区间内的细胞核。", [("nucleus_foci.py", "nucleus_area_px")], group="统计参数"),
            field("foci_area_px", "Foci 面积 (px²)", [2, 25], "pair_int", "整数范围：1 ≤ 下限 ≤ 上限；仅统计面积处于闭区间内的 foci。", [("nucleus_foci.py", "foci_area_px")], group="统计参数"),
            field("dapi_adjust_windows", "DAPI 拉伸窗口", "full", "window", "可填 full、none，或整数 low,high；数值范围：0 ≤ low < high ≤ 255。", [("nucleus_foci.py", "dapi_adjust_windows")], group="DAPI 调整"),
            field("dapi_adjust_contrast", "DAPI 对比度", 1.0, "float", "数值范围：> 0 的有限数；1 保持不变，常用建议 0.1–10。", [("nucleus_foci.py", "dapi_adjust_contrast")], group="DAPI 调整"),
            field("dapi_adjust_brightness", "DAPI 亮度", 0.0, "float", "数值范围：任意有限数；0 保持不变，8-bit 图像常用建议 −255–255。", [("nucleus_foci.py", "dapi_adjust_brightness")], group="DAPI 调整"),
            *sum(([field(f"channel{i}_adjust_window", f"通道 {i} 窗口", [0, 255], "pair_int", "整数范围：0 ≤ 下限 < 上限 ≤ 255。", [("nucleus_foci.py", f"channel{i}_adjust_window")], group="蛋白通道调整"),
                   field(f"channel{i}_adjust_contrast", f"通道 {i} 对比度", 10.0, "float", "数值范围：> 0 的有限数；1 保持不变，常用建议 0.1–10。", [("nucleus_foci.py", f"channel{i}_adjust_contrast")], group="蛋白通道调整"),
                   field(f"channel{i}_adjust_brightness", f"通道 {i} 亮度", 0.0, "float", "数值范围：任意有限数；0 保持不变，8-bit 图像常用建议 −255–255。", [("nucleus_foci.py", f"channel{i}_adjust_brightness")], group="蛋白通道调整")]
                  for i in range(1, 6)), []),
            field("plot_order", "分组顺序", "1,2", help_text="可填 default，或逗号分隔的不重复组号；每个组号范围为 1–N（N 为 CSV 中的组数），例如 1,3,2。", targets=[("foci_plot.py", "plot_order")], group="作图参数"),
            field("group_colors", "配色", "nature", kind="colors", help_text="三种方式：直接填写 nature、Matplotlib 渐变色或 N 个十六进制颜色；从带色带的预设列表单击选择；或用颜色板按第 1、2…组依次添加颜色。", targets=[("foci_plot.py", "group_colors")], group="作图参数"),
            field("wilcox_pairs", "Wilcoxon 比较", "all", help_text="可选 all、none，或配对列表；组号范围为当前显示组的 1–N，例如 (1,2),(2,3)。", targets=[("foci_plot.py", "wilcox_pairs")], group="作图参数"),
        ], stages=[("nucleus_foci.py", "图像统计", "run_step", "analysis"), ("foci_plot.py", "统计作图", "run_step", "plot")],
    ),
    dict(
        id="intensity", title="核内相对荧光强度", icon="03", warning=True,
        description="分割细胞核，计算各蛋白通道的核内相对荧光强度，并生成分组图与统计结果。",
        fields=[
            field("input_dir", "TIFF 母文件夹", "", "folder", "选择 lif2tif 生成的 *_tif 文件夹；其中应包含各 LIF 对应的子文件夹。", [("nuclear_intensity.py", "input_dir"), ("intensity_plot.py", "input_dir")], group="输入"),
            field("run_step", "本次运行步骤", "analysis", "choice", "二选一：图像统计生成 CSV/标注图；统计作图只读取已有 CSV，不重新分析图片。", choices=[("analysis", "仅运行图像统计"), ("plot", "仅生成统计图")], group="步骤"),
            field("foci_mode", "处理范围", "all", "choice", "可选范围：test 或 all；test 只处理首个子文件夹的首张合并图，all 处理全部。", [("nuclear_intensity.py", "foci_mode")], [("test", "测试一张"), ("all", "全部处理")], "统计参数"),
            field("nucleus_area_px", "细胞核面积 (px²)", [500, 20000], "pair_int", "整数范围：1 ≤ 下限 ≤ 上限；仅保留面积处于闭区间内的细胞核。", [("nuclear_intensity.py", "nucleus_area_px")], group="统计参数"),
            field("dapi_adjust_windows", "DAPI 拉伸窗口", "full", "window", "可填 full、none，或整数 low,high；数值范围：0 ≤ low < high ≤ 255。", [("nuclear_intensity.py", "dapi_adjust_windows")], group="DAPI 调整"),
            field("dapi_adjust_contrast", "DAPI 对比度", 1.0, "float", "数值范围：> 0 的有限数；1 保持不变，常用建议 0.1–10。", [("nuclear_intensity.py", "dapi_adjust_contrast")], group="DAPI 调整"),
            field("dapi_adjust_brightness", "DAPI 亮度", 0.0, "float", "数值范围：任意有限数；0 保持不变，8-bit 图像常用建议 −255–255。", [("nuclear_intensity.py", "dapi_adjust_brightness")], group="DAPI 调整"),
            *[field(f"channel{i}_threshold", f"通道 {i} 阈值", default, "pair_int", "整数范围：0 ≤ 下限 ≤ 上限 ≤ 255；仅累计此闭区间内的调整后灰度。", [("nuclear_intensity.py", f"channel{i}_threshold")], group="蛋白通道阈值") for i, default in enumerate(([125, 255], [60, 255], [0, 255], [0, 255], [0, 255]), 1)],
            field("plot_order", "分组顺序", "default", help_text="可填 default，或逗号分隔的不重复组号；每个组号范围为 1–N（N 为 CSV 中的组数），例如 1,3,2。", targets=[("intensity_plot.py", "plot_order")], group="作图参数"),
            field("group_colors", "配色", "nature", kind="colors", help_text="三种方式：直接填写 nature、Matplotlib 渐变色或 N 个十六进制颜色；从带色带的预设列表单击选择；或用颜色板按第 1、2…组依次添加颜色。", targets=[("intensity_plot.py", "group_colors")], group="作图参数"),
            field("wilcox_pairs", "Wilcoxon 比较", "(1,2),(1,3),(1,4),(1,5)", help_text="可选 all、none，或配对列表；组号范围为当前显示组的 1–N，例如 (1,2),(2,3)。", targets=[("intensity_plot.py", "wilcox_pairs")], group="作图参数"),
        ], stages=[("nuclear_intensity.py", "图像统计", "run_step", "analysis"), ("intensity_plot.py", "统计作图", "run_step", "plot")],
    ),
    dict(
        id="fiber", title="DNA Fiber", icon="04", warning=True,
        description="识别 DNA fiber 的红/绿片段，输出逐条纤维结果，并绘制复制叉速度和长度比。",
        fields=[
            field("input_dir", "图片母文件夹", "", "folder", "选择图片母文件夹；待处理的单张 RGB TIFF 应放在其各个分组子文件夹中。", [("DNA_fiber.py", "parent_folder"), ("fiber_plot.py", "input_dir")], group="输入"),
            field("run_step", "本次运行步骤", "analysis", "choice", "二选一：图像统计生成逐条纤维 CSV/标注图；统计作图只读取已有 CSV。", choices=[("analysis", "仅运行图像统计"), ("plot", "仅生成统计图")], group="步骤"),
            field("fiber_mode", "处理范围", "test", "choice", "可选范围：test 或 all；test 只处理首个子文件夹的首张图，all 处理全部。", [("DNA_fiber.py", "fiber_mode")], [("test", "测试一张"), ("all", "全部处理")], "统计参数"),
            field("green_contrast", "绿色对比度", 1.0, "float", "数值范围：≥ 0 的有限数；1 保持不变，常用建议 0–10。", [("DNA_fiber.py", "green_contrast")], group="统计参数"),
            field("green_brightness", "绿色亮度", 50.0, "float", "数值范围：任意有限数；8-bit 图像常用建议 −255–255。", [("DNA_fiber.py", "green_brightness")], group="统计参数"),
            field("green_threshold", "绿色阈值", 80.0, "float", "数值范围：0–255（含端点）；数值越大，保留的绿色信号越强。", [("DNA_fiber.py", "green_threshold")], group="统计参数"),
            field("red_contrast", "红色对比度", 1.0, "float", "数值范围：≥ 0 的有限数；1 保持不变，常用建议 0–10。", [("DNA_fiber.py", "red_contrast")], group="统计参数"),
            field("red_brightness", "红色亮度", 20.0, "float", "数值范围：任意有限数；8-bit 图像常用建议 −255–255。", [("DNA_fiber.py", "red_brightness")], group="统计参数"),
            field("red_threshold", "红色阈值", 80.0, "float", "数值范围：0–255（含端点）；数值越大，保留的红色信号越强。", [("DNA_fiber.py", "red_threshold")], group="统计参数"),
            field("analysis_mode", "作图内容", 3, "choice", "可选值：1 仅复制叉速度、2 仅长度比、3 两者都生成。", [("fiber_plot.py", "analysis_mode")], [(1, "复制叉速度"), (2, "长度比"), (3, "两者")], "作图参数"),
            field("IF_order", "标记顺序", "red_green", "choice", "可选 red_green 或 green_red；必须与两次核苷类似物的实际掺入先后顺序一致。", [("fiber_plot.py", "IF_order")], [("red_green", "红 → 绿"), ("green_red", "绿 → 红")], "作图参数"),
            field("scale", "像素/μm", 1.0, "float", "数值范围：> 0 的有限数；填写显微图像标定的每微米像素数。", [("fiber_plot.py", "scale")], group="作图参数"),
            field("time", "后标记时间 (min)", 15.0, "float", "数值范围：> 0 的有限数；单位为分钟。", [("fiber_plot.py", "time")], group="作图参数"),
            field("plot_order", "分组顺序", "2,1", help_text="填写逗号分隔的不重复组号，必须恰好覆盖 1–N 的全部组（N 为 CSV 组数），例如两组可填 2,1。", targets=[("fiber_plot.py", "plot_order")], group="作图参数"),
            field("group_colors", "配色", "nature", kind="colors", help_text="三种方式：直接填写 nature、Matplotlib 渐变色或 N 个十六进制颜色；从带色带的预设列表单击选择；或用颜色板按第 1、2…组依次添加颜色。", targets=[("fiber_plot.py", "group_colors")], group="作图参数"),
            field("wilcox_pairs", "Wilcoxon 比较", "all", help_text="可选 all、none，或配对列表；组号范围为 1–N，且只能引用当前显示组，例如 (1,2),(2,3)。", targets=[("fiber_plot.py", "wilcox_pairs")], group="作图参数"),
        ], stages=[("DNA_fiber.py", "图像统计", "run_step", "analysis"), ("fiber_plot.py", "统计作图", "run_step", "plot")],
    ),
    dict(
        id="colony", title="单克隆形成", icon="05", warning=True,
        description="自动识别培养皿或六孔板 ROI，分割并统计克隆，输出标注图和 CSV。",
        fields=[
            field("input_dir", "图片母文件夹", "", "folder", "选择图片母文件夹；待统计图片应放在其分组子文件夹中，支持 JPG、PNG 和单页 TIFF。", [("colony_formation.py", "parent_dir")], group="输入"),
            field("mode", "处理范围", "test", "choice", "可选范围：test 或 all；test 只处理首个子文件夹的首张图，all 处理全部。", [("colony_formation.py", "mode")], [("test", "测试一张"), ("all", "全部处理")], "统计参数"),
            field("area_range", "克隆面积 (px²)", [10, 12000], "pair_int", "整数范围：1 ≤ 下限 ≤ 上限；按基准 ROI 像素面积筛选克隆。", [("colony_formation.py", "area_range")], group="统计参数"),
            field("hough_votes", "圆检测票数", 110, "int", "正整数范围：≥ 1；越大越严格，漏孔时可尝试 70–100，误检时增大。", [("colony_formation.py", "hough_votes")], group="ROI 参数"),
            field("threshold_factor", "Otsu 阈值倍数", 1.0, "float", "数值范围：> 0 的有限数；小于 1 更易保留浅染色，大于 1 更严格。", [("colony_formation.py", "threshold_factor")], group="分割参数"),
            field("min_contrast", "最低灰度差", 8.0, "float", "数值范围：≥ 0 的有限数，8-bit 图像有效建议 0–255；用于抑制空白孔误计数。", [("colony_formation.py", "min_contrast")], group="分割参数"),
            field("peak_prominence", "距离峰突出度", 3.0, "float", "数值范围：> 0 的有限数；增大可减少相邻克隆的过度分割。", [("colony_formation.py", "peak_prominence")], group="分割参数"),
        ], stages=[("colony_formation.py", "克隆统计")],
    ),
]


class PageWidget(QWidget):
    def __init__(self, spec, saved):
        super().__init__()
        self.spec = spec
        self.widgets = {}
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 24, 28, 18)
        title = QLabel(spec["title"])
        title.setObjectName("pageTitle")
        desc = QLabel(spec["description"])
        desc.setObjectName("description")
        desc.setWordWrap(True)
        outer.addWidget(title)
        outer.addWidget(desc)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 16, 8, 16)
        groups = {}
        for item in spec["fields"]:
            group_name = item["group"]
            if group_name not in groups:
                card = QFrame()
                card.setObjectName("card")
                card_layout = QVBoxLayout(card)
                heading = QLabel(group_name)
                heading.setObjectName("sectionTitle")
                card_layout.addWidget(heading)
                form = QFormLayout()
                form.setLabelAlignment(Qt.AlignLeft)
                form.setHorizontalSpacing(22)
                form.setVerticalSpacing(12)
                card_layout.addLayout(form)
                body_layout.addWidget(card)
                groups[group_name] = form
            widget = self._create_widget(item, saved.get(item["key"], item["default"]))
            self.widgets[item["key"]] = widget
            label = QLabel(item["label"])
            label.setToolTip(item["help"])
            field_box = QWidget()
            field_layout = QVBoxLayout(field_box)
            field_layout.setContentsMargins(0, 0, 0, 0)
            field_layout.setSpacing(3)
            field_layout.addWidget(widget)
            help_label = QLabel(item["help"])
            help_label.setObjectName("parameterHelp")
            help_label.setWordWrap(True)
            field_layout.addWidget(help_label)
            groups[group_name].addRow(label, field_box)
        body_layout.addStretch()
        scroll.setWidget(body)
        outer.addWidget(scroll, 1)

    def _create_widget(self, item, value):
        kind = item["kind"]
        if kind == "check":
            w = QCheckBox()
            w.setChecked(bool(value))
        elif kind == "choice":
            w = NoWheelComboBox()
            for actual, label in item["choices"]:
                w.addItem(label, actual)
            idx = w.findData(value)
            w.setCurrentIndex(max(0, idx))
        elif kind == "colors":
            w = self._create_color_widget(item, value)
        elif kind == "folder":
            container = QWidget()
            layout = QHBoxLayout(container)
            layout.setContentsMargins(0, 0, 0, 0)
            edit = QLineEdit(str(value))
            edit.setPlaceholderText("请选择文件夹…")
            button = QPushButton("浏览…")
            button.clicked.connect(lambda: self._browse(edit))
            layout.addWidget(edit, 1)
            layout.addWidget(button)
            container.value_widget = edit
            w = container
        elif kind in ("pair_int", "pair_float"):
            container = QWidget()
            layout = QHBoxLayout(container)
            layout.setContentsMargins(0, 0, 0, 0)
            values = value if isinstance(value, (list, tuple)) and len(value) == 2 else ["", ""]
            low, high = QLineEdit(str(values[0])), QLineEdit(str(values[1]))
            low.setPlaceholderText("下限")
            high.setPlaceholderText("上限")
            layout.addWidget(low)
            layout.addWidget(QLabel("—"))
            layout.addWidget(high)
            container.value_widgets = (low, high)
            w = container
        else:
            w = QLineEdit(str(value))
        w.setToolTip(item["help"])
        return w

    def _browse(self, edit):
        start = edit.text().strip() or str(Path.home())
        selected = QFileDialog.getExistingDirectory(self, "选择文件夹", start)
        if selected:
            edit.setText(selected)

    def _create_color_widget(self, item, value):
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        direct_row = QHBoxLayout()
        direct_label = QLabel("直接填写")
        direct_label.setObjectName("parameterOption")
        edit = QLineEdit(str(value))
        edit.setPlaceholderText("nature、色图名，或 #RRGGBB,#RRGGBB…")
        direct_row.addWidget(direct_label)
        direct_row.addWidget(edit, 1)
        layout.addLayout(direct_row)

        select_row = QHBoxLayout()
        select_label = QLabel("预设色带")
        select_label.setObjectName("parameterOption")
        preset = NoWheelComboBox()
        preset.setIconSize(QSize(170, 18))
        preset.setMinimumWidth(360)
        preset.addItem("单击选择 Nature / Matplotlib 色图…", None)
        for name, icon in colorbar_icons().items():
            preset.addItem(icon, name, name)
        palette_button = QPushButton()
        select_row.addWidget(select_label)
        select_row.addWidget(preset, 1)
        select_row.addWidget(palette_button)
        layout.addLayout(select_row)

        container.value_widget = edit
        container.preset_widget = preset
        container.palette_button = palette_button
        container.help_text = item["help"]
        preset.activated.connect(lambda index: self._use_color_preset(container, index))
        palette_button.clicked.connect(lambda: self._choose_palette_color(container))
        edit.textChanged.connect(lambda: self._update_color_widget(container))
        self._update_color_widget(container)
        return container

    @staticmethod
    def _hex_colors(text):
        values = [part.strip().upper() for part in text.split(",") if part.strip()]
        return values if values and all(HEX_COLOR.fullmatch(value) for value in values) else []

    def _use_color_preset(self, container, index):
        value = container.preset_widget.itemData(index)
        if value:
            container.value_widget.setText(str(value))

    def _update_color_widget(self, container):
        text = container.value_widget.text().strip()
        colors = self._hex_colors(text)
        edit = container.value_widget
        if colors:
            if len(colors) == 1:
                background = colors[0]
            else:
                stops = ", ".join(
                    f"stop:{index / (len(colors) - 1):.3f} {color}"
                    for index, color in enumerate(colors))
                background = f"qlineargradient(x1:0, y1:0, x2:1, y2:0, {stops})"
            average = sum(QColor(color).lightness() for color in colors) / len(colors)
            foreground = "#FFFFFF" if average < 128 else "#172522"
            edit.setStyleSheet(
                f"QLineEdit {{ background: {background}; color: {foreground}; "
                "border: 1px solid #82979b; border-radius: 6px; padding: 7px; }}")
        else:
            edit.setStyleSheet("")

        preset_index = container.preset_widget.findData(text)
        container.preset_widget.blockSignals(True)
        container.preset_widget.setCurrentIndex(max(0, preset_index))
        container.preset_widget.blockSignals(False)
        container.palette_button.setText(f"颜色板：选择第 {len(colors) + 1} 组…")

    def _choose_palette_color(self, container):
        existing = self._hex_colors(container.value_widget.text().strip())
        dialog = QColorDialog(self)
        dialog.setWindowTitle(f"选择第 {len(existing) + 1} 组颜色")
        dialog.setOption(QColorDialog.DontUseNativeDialog, True)
        for index, value in enumerate(PRISM_COLORS):
            dialog.setCustomColor(index, QColor(value))
        dialog.setCurrentColor(QColor(existing[-1] if existing else PRISM_COLORS[len(existing) % len(PRISM_COLORS)]))
        if dialog.exec():
            existing.append(dialog.selectedColor().name(QColor.HexRgb).upper())
            container.value_widget.setText(",".join(existing))

    def raw_value(self, item):
        w = self.widgets[item["key"]]
        if item["kind"] == "check":
            return w.isChecked()
        if item["kind"] == "choice":
            return w.currentData()
        if item["kind"] in {"folder", "colors"}:
            return w.value_widget.text().strip()
        if item["kind"] in ("pair_int", "pair_float"):
            return [x.text().strip() for x in w.value_widgets]
        return w.text().strip()

    def parsed_values(self):
        values = {}
        for item in self.spec["fields"]:
            raw = self.raw_value(item)
            kind = item["kind"]
            try:
                if kind == "folder":
                    if not raw:
                        raise ValueError("尚未选择文件夹")
                    path = Path(raw).expanduser().resolve()
                    if not path.is_dir():
                        raise ValueError("文件夹不存在")
                    value = {"__path__": str(path)}
                elif kind == "int":
                    value = int(raw)
                elif kind == "float":
                    value = float(raw)
                    if not math.isfinite(value):
                        raise ValueError("必须是有限数值")
                elif kind == "pair_int":
                    value = {"__tuple__": [int(raw[0]), int(raw[1])]}
                elif kind == "pair_float":
                    value = {"__tuple__": [float(raw[0]), float(raw[1])]}
                elif kind == "window":
                    text = raw.strip().lower()
                    if text == "full":
                        value = "full"
                    elif text in ("none", "无", ""):
                        value = None
                    else:
                        parts = [int(x.strip()) for x in text.split(",")]
                        if len(parts) != 2:
                            raise ValueError("请填写 full、none 或 low,high")
                        if not 0 <= parts[0] < parts[1] <= 255:
                            raise ValueError("数值窗口必须满足 0 ≤ low < high ≤ 255")
                        value = {"__tuple__": parts}
                else:
                    value = raw
                self._validate_range(item, value)
            except ValueError as exc:
                raise ValueError(f"{item['label']}：{exc}") from exc
            values[item["key"]] = value
        return values

    @staticmethod
    def _validate_range(item, value):
        key = item["key"]
        if item["kind"] in {"pair_int", "pair_float"}:
            low, high = value["__tuple__"]
            if key in {"nucleus_area_px", "foci_area_px", "area_range"} and not 1 <= low <= high:
                raise ValueError("必须满足 1 ≤ 下限 ≤ 上限")
            if key.endswith("_adjust_window") and not 0 <= low < high <= 255:
                raise ValueError("必须满足 0 ≤ 下限 < 上限 ≤ 255")
            if key.endswith("_threshold") and not 0 <= low <= high <= 255:
                raise ValueError("必须满足 0 ≤ 下限 ≤ 上限 ≤ 255")
        if key == "hough_votes" and value < 1:
            raise ValueError("必须是 ≥ 1 的正整数")
        if key in {"dapi_adjust_contrast", "scale", "time", "threshold_factor", "peak_prominence"} and value <= 0:
            raise ValueError("必须是 > 0 的有限数")
        if key.endswith("_adjust_contrast") and value <= 0:
            raise ValueError("必须是 > 0 的有限数")
        if key in {"green_contrast", "red_contrast", "min_contrast"} and value < 0:
            raise ValueError("必须是 ≥ 0 的有限数")
        if key in {"green_threshold", "red_threshold"} and not 0 <= value <= 255:
            raise ValueError("必须在 0–255 范围内")

    def serializable_values(self):
        return {item["key"]: self.raw_value(item) for item in self.spec["fields"]}


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DDRimage 免疫荧光分析")
        self.resize(1180, 780)
        self.process = None
        self.log_buffer = ""
        saved = self._load_state()

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)

        top = QFrame()
        top.setObjectName("topbar")
        top_layout = QHBoxLayout(top)
        brand = QLabel("DDRimage")
        brand.setObjectName("brand")
        subtitle = QLabel("免疫荧光与图像定量")
        subtitle.setObjectName("subtitle")
        top_layout.addWidget(brand)
        top_layout.addWidget(subtitle)
        top_layout.addStretch()
        runtime = QLabel(f"Python {sys.version_info.major}.{sys.version_info.minor} · 本地运行")
        runtime.setObjectName("runtime")
        top_layout.addWidget(runtime)
        layout.addWidget(top)

        splitter = QSplitter(Qt.Horizontal)
        self.nav = QListWidget()
        self.nav.setObjectName("navigation")
        self.nav.setFixedWidth(230)
        self.stack = QStackedWidget()
        self.pages = []
        for spec in PAGES:
            self.nav.addItem(f"{spec['icon']}   {spec['title']}")
            page = PageWidget(spec, saved.get(spec["id"], {}))
            self.pages.append(page)
            self.stack.addWidget(page)
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)
        splitter.addWidget(self.nav)
        splitter.addWidget(self.stack)
        splitter.setStretchFactor(1, 1)
        bottom = QFrame()
        bottom.setObjectName("bottomPanel")
        bottom_layout = QVBoxLayout(bottom)
        controls = QHBoxLayout()
        self.status = QLabel("准备就绪")
        self.status.setObjectName("status")
        self.open_button = QPushButton("打开结果文件夹")
        self.stop_button = QPushButton("停止")
        self.stop_button.setEnabled(False)
        self.run_button = QPushButton("开始运行")
        self.run_button.setObjectName("primaryButton")
        self.open_button.clicked.connect(self.open_output)
        self.stop_button.clicked.connect(self.stop_run)
        self.run_button.clicked.connect(self.start_run)
        controls.addWidget(self.status)
        controls.addStretch()
        controls.addWidget(self.open_button)
        controls.addWidget(self.stop_button)
        controls.addWidget(self.run_button)
        self.log = QTextEdit()
        self.log.setObjectName("log")
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(70)
        self.log.setPlaceholderText("运行日志会显示在这里。")
        bottom_layout.addLayout(controls)
        bottom_layout.addWidget(self.log, 1)

        self.vertical_splitter = QSplitter(Qt.Vertical)
        self.vertical_splitter.setChildrenCollapsible(False)
        self.vertical_splitter.addWidget(splitter)
        self.vertical_splitter.addWidget(bottom)
        self.vertical_splitter.setStretchFactor(0, 1)
        self.vertical_splitter.setStretchFactor(1, 0)
        self.vertical_splitter.setSizes([560, 200])
        layout.addWidget(self.vertical_splitter, 1)

    def _load_state(self):
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_state(self):
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        state = {page.spec["id"]: page.serializable_values() for page in self.pages}
        STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    def current(self):
        return self.pages[self.nav.currentRow()]

    def build_jobs(self, page, values):
        script_values = {stage[0]: {} for stage in page.spec["stages"]}
        for item in page.spec["fields"]:
            for script, variable in item["targets"]:
                script_values.setdefault(script, {})[variable] = values[item["key"]]
        jobs = []
        for stage in page.spec["stages"]:
            script, label = stage[0], stage[1]
            expected = stage[3] if len(stage) >= 4 else True
            enabled = len(stage) < 3 or values.get(stage[2]) == expected
            if enabled:
                jobs.append(dict(script=script, label=label, overrides=script_values.get(script, {})))
        return jobs

    def start_run(self):
        page = self.current()
        try:
            values = page.parsed_values()
            jobs = self.build_jobs(page, values)
            if not jobs:
                raise ValueError("请至少选择一个运行步骤")
        except ValueError as exc:
            QMessageBox.warning(self, "参数有误", str(exc))
            return
        destructive_scripts = {"nucleus_foci.py", "nuclear_intensity.py", "DNA_fiber.py", "colony_formation.py"}
        if page.spec["warning"] and any(job["script"] in destructive_scripts for job in jobs):
            answer = QMessageBox.question(
                self, "确认运行",
                "按照原 Notebook 的规则，统计步骤会清理输入子文件夹内旧的 CSV 和对应结果 TIFF。\n\n建议先用“测试一张”检查参数。是否继续？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return

        self._save_state()
        RUN_FILE.parent.mkdir(parents=True, exist_ok=True)
        PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
        RUN_FILE.write_text(json.dumps({"jobs": jobs}, ensure_ascii=False, indent=2), encoding="utf-8")
        self.log.clear()
        self.log_buffer = ""
        self.log.append(f"工作流：{page.spec['title']}")
        self.log.append("步骤：" + " → ".join(job["label"] for job in jobs))
        self.process = QProcess(self)
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONUTF8", "1")
        env.insert("PYTHONUNBUFFERED", "1")
        env.insert("MPLBACKEND", "Agg")
        env.insert("DDRIMAGE_PREVIEW_DIR", str(PREVIEW_DIR))
        self.process.setProcessEnvironment(env)
        # Windows starts the GUI with pythonw.exe, so use python.exe for the
        # worker.  macOS/Linux use the same interpreter as the GUI.
        worker_python = (Path(sys.executable).with_name("python.exe")
                         if sys.platform == "win32" else Path(sys.executable))
        self.process.setProgram(str(worker_python))
        self.process.setArguments(["-u", str(APP_DIR / "runner.py"), str(RUN_FILE)])
        self.process.setWorkingDirectory(str(ROOT_DIR))
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.finished.connect(self.finished)
        self.process.errorOccurred.connect(self.process_error)
        self.process.start()
        self.status.setText("正在运行…")
        self.run_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.nav.setEnabled(False)

    def read_output(self):
        if not self.process:
            return
        data = bytes(self.process.readAllStandardOutput()).decode("utf-8", errors="replace")
        if data:
            self.log_buffer += data
            lines = self.log_buffer.splitlines(keepends=True)
            self.log_buffer = ""
            if lines and not lines[-1].endswith(("\n", "\r")):
                self.log_buffer = lines.pop()
            for line in lines:
                self._append_log_item(line.rstrip("\r\n"), newline=True)

    def _append_log_item(self, text, newline=False):
        cursor = self.log.textCursor()
        cursor.movePosition(QTextCursor.End)
        if text.startswith(PREVIEW_PREFIX):
            try:
                payload = json.loads(text[len(PREVIEW_PREFIX):])
                path = Path(payload["path"]).resolve()
                if not path.is_relative_to(PREVIEW_DIR.resolve()) or not path.is_file():
                    raise ValueError("预览文件不在 DDRimage 数据目录内")
                preview = QImage(str(path))
                if preview.isNull():
                    raise ValueError("无法读取预览图片")
                width = max(320, self.log.viewport().width() - 30)
                if preview.width() > width:
                    preview = preview.scaledToWidth(width, Qt.SmoothTransformation)
                cursor.insertBlock()
                cursor.insertText(str(payload.get("caption", "结果预览")))
                cursor.insertBlock()
                cursor.insertImage(preview)
                cursor.insertBlock()
            except Exception as exc:
                cursor.insertText(f"[无法显示结果预览：{exc}]")
                if newline:
                    cursor.insertBlock()
        else:
            cursor.insertText(text)
            if newline:
                cursor.insertBlock()
        self.log.setTextCursor(cursor)
        self.log.ensureCursorVisible()

    def finished(self, exit_code, _status):
        self.read_output()
        if self.log_buffer:
            self._append_log_item(self.log_buffer)
            self.log_buffer = ""
        ok = exit_code == 0
        self.status.setText("运行完成" if ok else f"运行失败（代码 {exit_code}）")
        self.run_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.nav.setEnabled(True)
        if ok:
            QMessageBox.information(self, "完成", "所有选定步骤已完成。")
        else:
            QMessageBox.critical(self, "运行失败", "分析未完成，请查看下方日志中的最后一段错误信息。")
        self.process = None

    def process_error(self, _error):
        if self.process:
            self.log.append("\n无法启动分析进程：" + self.process.errorString())

    def stop_run(self):
        if self.process and self.process.state() != QProcess.NotRunning:
            self.process.kill()
            self.status.setText("已停止")

    def open_output(self):
        page = self.current()
        item = next((x for x in page.spec["fields"] if x["key"] == "input_dir"), None)
        if not item:
            return
        raw = page.raw_value(item)
        if not raw:
            QMessageBox.information(self, "提示", "请先选择输入文件夹。")
            return
        path = Path(raw)
        if page.spec["id"] == "lif":
            candidate = path.with_name(path.name + "_tif")
            if candidate.exists():
                path = candidate
        if not path.exists():
            QMessageBox.warning(self, "无法打开", "文件夹不存在。")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.resolve())))

    def closeEvent(self, event):
        if self.process and self.process.state() != QProcess.NotRunning:
            if QMessageBox.question(self, "退出", "分析仍在运行，确定停止并退出吗？") != QMessageBox.Yes:
                event.ignore()
                return
            self.process.kill()
        self._save_state()
        event.accept()


STYLE = """
QWidget { font-family: "Segoe UI", "Microsoft YaHei UI"; font-size: 10pt; color: #263238; }
QMainWindow, QWidget { background: #f5f7f9; }
#topbar { background: #ffffff; border-bottom: 1px solid #dfe5e8; }
#brand { color: #126b62; font-size: 19pt; font-weight: 700; padding: 7px 4px 7px 16px; }
#subtitle, #runtime { color: #60757a; }
#navigation { background: #173f3b; color: #eaf5f3; border: none; padding: 14px 8px; outline: none; }
#navigation::item { height: 48px; padding-left: 13px; margin: 3px 0; border-radius: 7px; }
#navigation::item:selected { background: #2b6f67; color: white; }
#navigation::item:hover:!selected { background: #22534e; }
#pageTitle { font-size: 20pt; font-weight: 650; color: #173f3b; }
#description { color: #60757a; padding-bottom: 4px; }
#parameterHelp { color: #6f8084; font-size: 9pt; padding: 1px 2px 3px 2px; }
#parameterOption { color: #526b70; min-width: 60px; }
#card { background: white; border: 1px solid #dde5e7; border-radius: 9px; padding: 12px; margin-bottom: 9px; }
#sectionTitle { font-size: 11pt; font-weight: 650; color: #255e58; padding-bottom: 6px; }
QLineEdit, QComboBox, QTextEdit { background: white; border: 1px solid #cbd7da; border-radius: 6px; padding: 7px; selection-background-color: #2c8177; }
QLineEdit:focus, QComboBox:focus { border: 1px solid #2c8177; }
QPushButton { background: #ffffff; border: 1px solid #bdcacc; border-radius: 6px; padding: 7px 14px; }
QPushButton:hover { background: #eef5f4; }
QPushButton:disabled { color: #9aa7aa; background: #edf0f1; }
#primaryButton { color: white; background: #14786e; border: 1px solid #14786e; font-weight: 650; padding: 8px 22px; }
#primaryButton:hover { background: #0f685f; }
#bottomPanel { background: #ffffff; border-top: 1px solid #dfe5e8; padding: 8px 14px 12px 14px; }
#status { color: #42635f; font-weight: 600; }
#log { background: #172522; color: #d9ebe8; border: none; font-family: Consolas, "Microsoft YaHei UI"; font-size: 9pt; }
QSplitter::handle:vertical { height: 7px; background: #d7e1e3; }
QSplitter::handle:vertical:hover { background: #2c8177; }
QScrollBar:vertical { width: 11px; background: transparent; }
QScrollBar::handle:vertical { background: #bdcacc; min-height: 28px; border-radius: 5px; }
"""


def main():
    if sys.platform == "win32":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DDRimage.Desktop")
        except Exception:
            pass
    app = QApplication(sys.argv)
    app.setApplicationName("DDRimage")
    if ICON_FILE.is_file():
        app.setWindowIcon(QIcon(str(ICON_FILE)))
    if sys.platform == "win32":
        app.setFont(QFont("Microsoft YaHei UI", 10))
    app.setStyleSheet(STYLE)
    window = MainWindow()
    window.show()
    raise SystemExit(app.exec())


if __name__ == "__main__":
    main()
